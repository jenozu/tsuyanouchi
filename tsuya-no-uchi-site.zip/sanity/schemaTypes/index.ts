import { product } from './product'

export const schemaTypes = [product]
