# IMPLEMENTATION PLAN: Koji Features into Tsuya Project

This document outlines a phased approach to integrate the advanced features and backend infrastructure from the Koji project into the Tsuya project, while preserving Tsuya's existing UI/UX. The plan is structured to ensure a systematic migration, focusing on backend first, then core functionalities, and finally the administrative interface and deployment.

## Overall Goal
To achieve feature parity with Koji in the Tsuya project, leveraging Supabase for backend and storage, Stripe for payments, and implementing a comprehensive admin dashboard, all while maintaining Tsuya's current design and user experience.

## Phases of Implementation

### Phase 1: Backend Infrastructure Migration (Supabase)

This initial phase focuses on transitioning Tsuya's data storage and management to Supabase. The primary objective is to replace the existing file-based product storage with a robust Supabase (Postgres) backend for products, categories, and orders, alongside Supabase Storage for product images.

**Key Tasks:**

1.  **Supabase Project Setup:** A new Supabase project will be created, and the necessary API credentials, specifically `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`, will be obtained for integration. These keys are crucial for connecting the Tsuya application to the Supabase services.

2.  **Database Schema Creation:** The database schema will be established by executing SQL migrations. These migrations will create tables for `products`, `categories`, `orders`, `order_items`, and `favorites`, mirroring the structure found in Koji's `SUPABASE_SETUP.md` and `STRIPE_DATABASE_MIGRATION.sql`. Concurrently, Row Level Security (RLS) policies will be implemented to ensure data integrity and access control. This includes public read access for products, admin-only write permissions, allowing order inserts during checkout, and restricting order status updates to administrators.

3.  **Supabase Storage Setup:** A dedicated `product-images` bucket will be created within Supabase Storage. This bucket will be configured with public read policies to allow the application to display product images to users.

4.  **Supabase Client and Helpers Integration:** The Supabase client will be initialized in `lib/supabase-client.ts`. Subsequently, Koji's `lib/supabase-helpers.ts` will be ported to Tsuya, adapting its product, order, and shipping rate functions to interact with the newly configured Supabase client. This step effectively replaces the existing `lib/product-storage.ts`.

5.  **Product Data Migration:** A one-time script will be developed to facilitate the migration of existing product data from Tsuya's `products.json` file to the new Supabase `products` table. This ensures that all current product information is preserved and accessible within the new backend.

6.  **Update Product Data Access:** The `lib/products.ts` file in Tsuya will be modified to retrieve product data directly from Supabase, replacing its reliance on `lib/product-storage.ts`. Following this, the `lib/product-storage.ts` file and any associated file system operations will be removed, completing the backend transition for product data.

**Done Checklist for Phase 1:**

| Item | Status |
| :--- | :--- |
| Supabase project created and API keys obtained. | ☐ |
| All required database tables (`products`, `categories`, `orders`, `order_items`, `favorites`, `shipping_rates`) created in Supabase. | ☐ |
| RLS policies configured for `products` and `orders` tables. | ☐ |
| `product-images` bucket created in Supabase Storage with public read access. | ☐ |
| `lib/supabase-client.ts` and `lib/supabase-helpers.ts` implemented in Tsuya. | ☐ |
| Existing product data successfully migrated to Supabase. | ☐ |
| `lib/products.ts` updated to use Supabase backend. | ☐ |
| `lib/product-storage.ts` removed. | ☐ |

### Phase 2: Core E-commerce Features (Cart, Favorites, Checkout)

This phase focuses on integrating essential e-commerce functionalities such as the shopping cart, favorites list, and the complete checkout process. The goal is to leverage Koji's proven client-side logic and adapt it to Tsuya's UI, ensuring seamless integration with the new Supabase backend.

**Key Tasks:**

1.  **Cart Functionality:** The `lib/cart-context.tsx` from Koji will be ported to Tsuya. This will establish a robust shopping cart system with localStorage persistence, allowing users to maintain their cart contents across sessions. The cart functionality will then be integrated into Tsuya's user interface, specifically updating components like `components/navbar.tsx` to display cart icons and item counts. A dedicated `app/cart/page.tsx` will be created, drawing inspiration from Koji's implementation to provide a comprehensive cart viewing and management experience.

2.  **Favorites Functionality:** Similarly, Koji's `lib/favorites-context.tsx` will be integrated into Tsuya. This will enable users to mark and manage their favorite products, with the list persisting in localStorage. The favorites functionality will be reflected in Tsuya's UI, such as a heart icon in `components/navbar.tsx`. A new `app/favorites/page.tsx` will be developed, based on Koji's design, to allow users to view and manage their favorited items.

3.  **Checkout Flow Implementation:** A complete checkout flow will be implemented by creating `app/checkout/page.tsx`, adapting the UI components to align with Tsuya's existing styling. This implementation will prioritize guest checkout functionality, allowing users to complete purchases without requiring an account. The checkout process will integrate with the new Supabase `orders` table for secure and efficient order creation. Furthermore, shipping rate calculation will be incorporated, utilizing `api/shipping/rates` and the functions within `lib/supabase-helpers.ts` to determine accurate shipping costs.

**Done Checklist for Phase 2:**

| Item | Status |
| :--- | :--- |
| Cart context and UI integrated, with localStorage persistence. | ☐ |
| Favorites context and UI integrated, with localStorage persistence. | ☐ |
| `app/cart/page.tsx` and `app/favorites/page.tsx` created and functional. | ☐ |
| `app/checkout/page.tsx` created, allowing guest checkout. | ☐ |
| Checkout process successfully creates orders in Supabase. | ☐ |
| Shipping rate calculation integrated into checkout. | ☐ |

### Phase 3: Stripe Payment Integration

This phase is dedicated to establishing a secure and functional payment gateway using Stripe. The primary objective is to implement Stripe PaymentIntents for processing transactions and to configure webhooks for real-time updates on order statuses.

**Key Tasks:**

1.  **Stripe API Keys Configuration:** The necessary API keys, including `STRIPE_SECRET_KEY`, `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`, and `STRIPE_WEBHOOK_SECRET`, will be obtained from the Stripe dashboard. These keys will then be securely configured in Tsuya's `.env.local` file for local development and as environment variables within the Vercel deployment environment.

2.  **Stripe Utilities:** Koji's `lib/stripe.ts` file will be ported to Tsuya. This file contains essential utility functions, such as `createPaymentIntent` for initiating payment processes and `verifyWebhookSignature` for ensuring the authenticity of incoming Stripe webhook events.

3.  **Payment Intent API Endpoints:** New API endpoints will be created at `app/api/payments/create-intent/route.ts` and `app/api/payments/update-intent/route.ts`. These endpoints will be based on Koji's implementation and will handle the creation and subsequent updates of Stripe PaymentIntents, facilitating the payment process.

4.  **Stripe Webhook Handler:** A dedicated webhook handler will be implemented at `app/api/webhooks/stripe/route.ts`. This handler will be responsible for processing Stripe events, particularly `payment_intent.succeeded` and `payment_intent.payment_failed`. Upon successful payment, the webhook will update the corresponding order status in Supabase and trigger the necessary email notifications to both the customer and the admin.

5.  **Integrate Stripe Elements in Checkout:** The `app/checkout/page.tsx` will be modified to incorporate `@stripe/react-stripe-js` and the `PaymentElement`. This integration will enable the secure collection of payment details directly within Tsuya's checkout interface. The implementation will also include logic to handle payment confirmation and redirect the user to a thank-you page upon successful transaction completion.

**Done Checklist for Phase 3:**

| Item | Status |
| :--- | :--- |
| Stripe API keys and webhook secret configured in environment variables. | ☐ |
| `lib/stripe.ts` implemented. | ☐ |
| Stripe payment intent API endpoints created and functional. | ☐ |
| Stripe webhook handler (`app/api/webhooks/stripe/route.ts`) implemented and tested. | ☐ |
| Checkout page successfully processes payments via Stripe PaymentIntents. | ☐ |
| Orders are marked as paid/processing in Supabase upon successful payment. | ☐ |

### Phase 4: Admin Dashboard and Authentication

This phase focuses on integrating Koji's comprehensive admin dashboard features into Tsuya, providing administrators with robust tools for managing products, orders, and analytics. A simple, password-based authentication system will also be implemented for secure access.

**Key Tasks:**

1.  **Admin Authentication:** A new admin login page will be created at `app/admin/login/page.tsx`, along with an API route for authentication at `app/api/admin/auth/route.ts`. This system will utilize a simple password-based authentication mechanism, as outlined in Koji's `GUEST_CHECKOUT_CHANGES.md`. Tsuya's existing `app/admin/page.tsx` will be updated to enforce this new authentication, and any legacy `next-auth` related admin authentication logic will be removed.

2.  **Admin Dashboard UI Integration:** The logic and components from Koji's `app/admin/dashboard/page.tsx` will be merged into Tsuya's `app/admin/page.tsx`. This integration will involve adapting Koji's UI elements to maintain consistency with Tsuya's existing styling and design principles.

3.  **Product Management (CRUD):** Full Create, Read, Update, and Delete (CRUD) functionalities for products will be implemented within the admin dashboard. These operations will leverage the `lib/supabase-helpers.ts` for interacting with the Supabase backend. A key feature will be the integration of image upload capabilities to Supabase Storage directly within the product management interface.

4.  **Order Management:** The admin dashboard will gain comprehensive order management features, including the ability to list all orders, view detailed order information, and update order statuses. These functionalities will also rely on `lib/supabase-helpers.ts` for data interaction.

5.  **Analytics and Reporting:** Koji's analytics features, encompassing sales data, inventory levels, and category performance, will be integrated into Tsuya's admin dashboard. This will involve utilizing `recharts` for data visualization, or adapting to any existing charting libraries present in Tsuya, to provide administrators with insightful reports.

6.  **Shipping Rate Management:** CRUD operations for managing shipping rates will be added to the admin dashboard. This will allow administrators to define and update shipping costs based on various criteria, using the `lib/supabase-helpers.ts` for backend interaction.

**Done Checklist for Phase 4:**

| Item | Status |
| :--- | :--- |
| Admin login page and password authentication implemented. | ☐ |
| Tsuya's admin page protected by the new authentication. | ☐ |
| Koji's admin dashboard features (product CRUD, order management, analytics, shipping rates) integrated into Tsuya's admin page. | ☐ |
| Product image upload to Supabase Storage functional from admin. | ☐ |
| Order status updates functional from admin. | ☐ |
| Analytics charts displaying data (even if mock initially). | ☐ |

### Phase 5: Email Notifications

This phase focuses on implementing automated email notifications to enhance the user experience and administrative efficiency. The objective is to send order confirmations to customers and new order alerts to the administrators using the Resend email platform.

**Key Tasks:**

1.  **Resend API Key Configuration:** The `RESEND_API_KEY` will be obtained from the Resend platform, and the `ORDER_NOTIFICATION_EMAIL` will be configured. These credentials will be added to Tsuya's `.env.local` file and set as environment variables in the Vercel deployment.

2.  **Email Utilities:** Koji's `lib/email.ts` file, which contains the `sendOrderNotificationEmail` and `sendOrderConfirmationEmail` functions, will be ported to Tsuya. These functions are responsible for generating and sending the respective email types.

3.  **Integrate Emails with Webhook:** The `app/api/webhooks/stripe/route.ts` will be modified to integrate the email sending functionality. Upon a successful payment event from Stripe, this webhook will trigger both `sendOrderConfirmationEmail` to the customer and `sendOrderNotificationEmail` to the designated administrator, ensuring timely communication.

**Done Checklist for Phase 5:**

| Item | Status |
| :--- | :--- |
| Resend API key and notification email configured. | ☐ |
| `lib/email.ts` implemented. | ☐ |
| Customer order confirmation emails sent automatically after successful payment. | ☐ |
| Admin new order notification emails sent automatically after successful payment. | ☐ |

### Phase 6: Deployment and Documentation

This final phase ensures that the integrated Tsuya project can be cleanly deployed on Vercel. It also includes updating all necessary documentation and providing a comprehensive launch checklist to guide future deployments and maintenance.

**Key Tasks:**

1.  **Environment Variable Documentation:** The `.env.local.example` file will be thoroughly updated to include all newly introduced environment variables related to Supabase, Stripe, and Resend. This provides a clear reference for developers setting up the project.

2.  **README Updates:** The main `README.md` file will be updated with detailed setup instructions for Supabase, Stripe, and the Vercel deployment process. This ensures that anyone working with the project can easily understand and configure the necessary services.

3.  **Vercel Deployment Configuration:** All environment variables will be verified and correctly configured within the Vercel dashboard for Production, Preview, and Development environments. A crucial step will be to ensure that the `npm run build` command executes successfully, indicating a clean and deployable application.

4.  **Launch Checklist:** A concise 
comprehensive launch checklist will be created to guide the final verification steps before the project goes live.

**Done Checklist for Phase 6:**

| Item | Status |
| :--- | :--- |
| `.env.local.example` updated with all new environment variables. | ☐ |
| `README.md` updated with Supabase, Stripe, and Vercel setup steps. | ☐ |
| All environment variables configured in Vercel for all environments. | ☐ |
| `npm run build` passes cleanly. | ☐ |
| Comprehensive launch checklist created. | ☐ |

### Phase 7: Final Review and Deliverables

This final phase involves a thorough review of the entire integration, ensuring all requirements are met, and compiling all necessary deliverables for the user.

**Key Tasks:**

1.  **Repo Parity Audit Review:** Review the initial parity audit and confirm all identified missing features have been addressed.
2.  **Code Changes Compilation:** Compile a file-by-file change list, including added, modified, and deleted files. For modified files, provide full updated code or unified diffs. For added files, provide full contents.
3.  **Database and Storage Setup Documentation:** Consolidate all Supabase SQL schema migrations, storage bucket setup instructions, and RLS policies into a clear, actionable document.
4.  **Stripe Integration Documentation:** Document the Stripe setup process, including environment variables, webhook configuration, and dashboard steps.
5.  **Vercel Deployment Documentation:** Provide clear instructions for Vercel deployment, including environment variable setup and build notes.
6.  **Test Checklist:** Finalize the 
test checklist for manual verification of all integrated features.
7.  **Comprehensive Integration Plan Document:** Compile all sections (Parity Audit, Implementation Plan, File Changes, Supabase Setup, Stripe Setup, Vercel Deployment, Test Checklist) into a single, well-structured Markdown document.

**Done Checklist for Phase 7:**

| Item | Status |
| :--- | :--- |
| Repo parity audit reviewed and confirmed. | ☐ |
| File-by-file change list compiled. | ☐ |
| Database and storage setup documentation completed. | ☐ |
| Stripe integration documentation completed. | ☐ |
| Vercel deployment documentation completed. | ☐ |
| Final test checklist created. | ☐ |
| Comprehensive integration plan document compiled and delivered. | ☐ |

## FILE CHANGES

This section will detail all file changes (added, modified, deleted) required to achieve feature parity. For modified files, full updated code or unified diffs will be provided. For added files, full contents will be provided.

### Added Files

*   `/lib/supabase-client.ts`
*   `/lib/supabase-helpers.ts`
*   `/lib/cart-context.tsx`
*   `/lib/favorites-context.tsx`
*   `/lib/stripe.ts`
*   `/app/cart/page.tsx`
*   `/app/checkout/page.tsx`
*   `/app/admin/login/page.tsx`
*   `/app/api/admin/auth/route.ts`
*   `/app/api/payments/create-intent/route.ts`
*   `/app/api/payments/update-intent/route.ts`
*   `/app/api/webhooks/stripe/route.ts`
*   `/lib/email.ts`
*   `/app/favorites/page.tsx`
*   `/app/api/shipping/rates/route.ts`

### Modified Files

*   `/package.json`
*   `/lib/products.ts`
*   `/components/navbar.tsx`
*   `/app/layout.tsx`
*   `/app/admin/page.tsx`
*   `/app/api/products/route.ts`
*   `/app/api/products/[id]/route.ts`
*   `/app/api/upload/route.ts`
*   `/app/thank-you/page.tsx`
*   `/components/navbar-wrapper.tsx`
*   `/auth.ts`
*   `/.env.local.example`
*   `/README.md`

### Deleted Files

*   `/lib/product-storage.ts`
*   `/sanity.config.ts`
*   `/sanity/` (directory)
*   `@auth/prisma-adapter` (dependency)
*   `@prisma/client` (dependency)
*   `prisma` (dependency)
*   `next-auth` (dependency, will be re-added with a different configuration for admin only)

## CODE

This section will contain the full code for all added files and unified diffs for modified files, grouped by file path.

## SUPABASE SETUP

This section will provide detailed instructions for setting up Supabase, including SQL schema migrations, storage bucket configuration, and Row Level Security (RLS) policies.

### SQL Schema Migrations

```sql
-- Products table
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL,
  cost NUMERIC(10, 2),
  category TEXT NOT NULL,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  sizes JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Categories table (optional, if separate categories management is desired)
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Orders table
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  items JSONB NOT NULL,
  subtotal NUMERIC(10, 2) NOT NULL,
  taxes NUMERIC(10, 2) NOT NULL,
  shipping NUMERIC(10, 2) NOT NULL,
  total NUMERIC(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  shipping_address JSONB NOT NULL,
  payment_intent_id TEXT,
  payment_status TEXT DEFAULT 'pending',
  payment_method TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Shipping Rates table
CREATE TABLE IF NOT EXISTS shipping_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  country_code TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(country_code)
);

-- Favorites table (optional, if server-side favorites are desired)
CREATE TABLE favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);

-- Indexes for performance
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX idx_orders_email ON orders(email);
CREATE INDEX idx_orders_payment_intent_id ON orders(payment_intent_id);
CREATE INDEX idx_orders_payment_status ON orders(payment_status);
CREATE INDEX idx_shipping_rates_country ON shipping_rates(country_code);
CREATE INDEX idx_favorites_user_product ON favorites(user_id, product_id);

-- Enable Row Level Security
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipping_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow public read access to products" ON products FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to products" ON products FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow public read access to categories" ON categories FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to categories" ON categories FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow orders insert for checkout" ON orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow admin full access to orders" ON orders FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow public read shipping_rates" ON shipping_rates FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to shipping_rates" ON shipping_rates FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

CREATE POLICY "Allow user to view their own favorites" ON favorites FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Allow user to insert their own favorites" ON favorites FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Allow user to delete their own favorites" ON favorites FOR DELETE USING (auth.uid() = user_id);
```

### Supabase Storage Setup

1.  In Supabase Dashboard, navigate to **Storage**.
2.  Create a new bucket named `product-images`.
3.  Ensure the bucket is marked as **Public**.
4.  Configure policies for the `product-images` bucket to allow public read access and authenticated write access (for admin image uploads).

## STRIPE SETUP

This section details the necessary steps for configuring Stripe integration, including environment variables, webhook setup, and dashboard configurations.

### Environment Variables

Add the following to your `.env.local` file and configure them in your Vercel project settings:

```env
# Stripe Configuration
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
```

### Webhook Configuration

1.  **Local Development (using Stripe CLI):**
    *   Install the Stripe CLI.
    *   Log in to Stripe CLI: `stripe login`.
    *   Forward webhooks to your local server: `stripe listen --forward-to localhost:3000/api/webhooks/stripe`.
    *   Copy the webhook signing secret (starts with `whsec_`) and set it as `STRIPE_WEBHOOK_SECRET`.
2.  **Production (Deployed Site):**
    *   In your Stripe Dashboard, go to **Developers** → **Webhooks**.
    *   Add an endpoint with the URL: `https://yourdomain.com/api/webhooks/stripe`.
    *   Select events to listen for: `payment_intent.succeeded` and `payment_intent.payment_failed`.
    *   Copy the signing secret for this endpoint and set it as `STRIPE_WEBHOOK_SECRET` in your Vercel environment variables.

## VERCEL DEPLOYMENT

This section provides guidance for deploying the integrated Tsuya project on Vercel.

### Environment Variables

Ensure all the following environment variables are set in your Vercel project settings for **Production**, **Preview**, and **Development** environments:

*   `NEXT_PUBLIC_SUPABASE_URL`
*   `NEXT_PUBLIC_SUPABASE_ANON_KEY`
*   `ADMIN_PASSWORD`
*   `STRIPE_SECRET_KEY`
*   `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
*   `STRIPE_WEBHOOK_SECRET`
*   `RESEND_API_KEY`
*   `ORDER_NOTIFICATION_EMAIL`
*   `RESEND_FROM_EMAIL` (Optional, defaults to `KojixKoji Store <onboarding@resend.dev>`)

### Build Notes

*   Verify that `npm run build` passes without errors locally before deploying.
*   Ensure all necessary dependencies are listed in `package.json`.

## TEST CHECKLIST

This checklist provides manual steps to verify the successful integration of all Koji features into the Tsuya project.

### General

*   [ ] Application builds successfully (`npm run build`).
*   [ ] All environment variables are correctly configured and loaded.

### Products

*   [ ] Products are fetched from Supabase and displayed correctly on the shop page.
*   [ ] Product detail pages load correctly with data from Supabase.
*   [ ] `lib/product-storage.ts` and related file-based product logic are removed.

### Cart & Favorites

*   [ ] Items can be added to and removed from the cart.
*   [ ] Cart contents persist across page reloads (using localStorage).
*   [ ] Cart item count updates correctly in the navbar.
*   [ ] Products can be added to and removed from favorites.
*   [ ] Favorites persist across page reloads (using localStorage).
*   [ ] Favorites page displays favorited items correctly.

### Checkout & Orders

*   [ ] Guest checkout flow is functional.
*   [ ] Shipping address and contact information can be entered.
*   [ ] Shipping rates are calculated and applied correctly.
*   [ ] Payment form loads correctly using Stripe Elements.
*   [ ] Test payments are processed successfully via Stripe PaymentIntents.
*   [ ] Orders are created in the Supabase `orders` table with correct details.
*   [ ] Thank-you page is displayed after successful checkout.

### Admin Dashboard

*   [ ] Admin login page is accessible at `/admin/login`.
*   [ ] Admin can log in using the configured `ADMIN_PASSWORD`.
*   [ ] Admin dashboard is accessible after successful login.
*   [ ] Product CRUD (Create, Read, Update, Delete) operations are functional.
*   [ ] Images can be uploaded to Supabase Storage from the product editor.
*   [ ] Orders can be viewed, detailed, and their statuses updated in the admin panel.
*   [ ] Analytics charts display relevant data (sales, inventory, categories).
*   [ ] Shipping rates can be managed (CRUD) in the admin settings.

### Stripe Integration

*   [ ] Stripe webhook endpoint receives `payment_intent.succeeded` events.
*   [ ] Order status in Supabase is updated to `processing` upon successful payment via webhook.
*   [ ] `payment_intent_id`, `payment_status`, and `payment_method` fields are populated in the Supabase `orders` table.

### Email Notifications

*   [ ] Customer receives an order confirmation email after successful payment.
*   [ ] Admin receives a new order notification email after successful payment.
*   [ ] Email content is accurate and well-formatted.

## LAUNCH CHECKLIST

*   [ ] All `TODO` comments in the codebase addressed.
*   [ ] All `console.log` statements removed or replaced with proper logging.
*   [ ] Production Stripe API keys and webhook secret configured in Vercel.
*   [ ] Production Resend API key and `ORDER_NOTIFICATION_EMAIL` configured.
*   [ ] Custom domain configured in Vercel.
*   [ ] SSL certificate is active.
*   [ ] Application is responsive on various devices.
*   [ ] Basic performance testing completed.
*   [ ] Error monitoring (e.g., Sentry, Vercel Analytics) configured.
*   [ ] Backup strategy for Supabase data in place.
*   [ ] Final review of all features by stakeholders.

