# PARITY AUDIT: Koji vs. Tsuya

## Feature Comparison

| Feature | Koji (Reference) | Tsuya (Target) | Status | Action Required |
| :--- | :--- | :--- | :--- | :--- |
| **Backend** | Supabase (Postgres) | File-based (JSON) | ❌ Missing | Migrate to Supabase |
| **Storage** | Supabase Storage | Local File System | ❌ Missing | Migrate to Supabase Storage |
| **Cart** | localStorage + Context | Not implemented | ❌ Missing | Port Koji Cart logic |
| **Favorites** | localStorage + Context | Not implemented | ❌ Missing | Port Koji Favorites logic |
| **Checkout** | Guest Checkout + Stripe | Not implemented | ❌ Missing | Port Koji Checkout flow |
| **Payments** | Stripe PaymentIntents | Not implemented | ❌ Missing | Port Stripe integration |
| **Admin Auth** | Password-based | NextAuth (Google) | ⚠️ Partial | Switch to Password-based for v1 |
| **Admin Dashboard** | Full CRUD + Analytics | Partial CRUD + AI | ⚠️ Partial | Merge Koji features into Tsuya UI |
| **Order Management** | List/Detail/Status | Not implemented | ❌ Missing | Port Order management |
| **Shipping Rates** | DB-driven (Supabase) | Not implemented | ❌ Missing | Port Shipping logic |
| **Email Notifications** | Resend integration | Not implemented | ❌ Missing | Port Resend integration |

## Repository Structure Mapping

| Koji Path | Tsuya Equivalent | Note |
| :--- | :--- | :--- |
| `lib/supabase-client.ts` | `lib/supabase-client.ts` | New file |
| `lib/supabase-helpers.ts` | `lib/supabase-helpers.ts` | New file (replaces `lib/product-storage.ts`) |
| `lib/cart-context.tsx` | `lib/cart-context.tsx` | New file |
| `lib/favorites-context.tsx` | `lib/favorites-context.tsx` | New file |
| `lib/stripe.ts` | `lib/stripe.ts` | New file |
| `app/cart/page.tsx` | `app/cart/page.tsx` | New file |
| `app/checkout/page.tsx` | `app/checkout/page.tsx` | New file |
| `app/admin/login/page.tsx` | `app/admin/login/page.tsx` | New file |
| `app/admin/dashboard/page.tsx` | `app/admin/page.tsx` | Merge logic into Tsuya's admin page |
| `app/api/webhooks/stripe/route.ts` | `app/api/webhooks/stripe/route.ts` | New file |
| `app/api/payments/...` | `app/api/payments/...` | New files |
| `app/api/admin/...` | `app/api/admin/...` | New files |

## Legacy Dependencies to Remove (Tsuya)
- `sanity`, `next-sanity`, `@sanity/client` (If not used)
- `prisma`, `@prisma/client`, `@auth/prisma-adapter` (Replacing with Supabase)
- `next-auth` (Replacing with simple password auth for admin as per Koji)
