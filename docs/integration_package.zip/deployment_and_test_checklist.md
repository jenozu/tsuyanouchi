# DEPLOYMENT AND TEST CHECKLIST

This document provides a comprehensive checklist for deploying the integrated Tsuya project on Vercel and performing final manual verification of all features. The aim is to ensure a smooth transition to production and validate the complete functionality of the integrated system.

## 1. Vercel Deployment Readiness

Before initiating deployment to a production environment, it is crucial to confirm that all prerequisites are met. This section outlines the key areas that require verification to ensure a successful and stable deployment on Vercel.

### Environment Variable Configuration

All necessary environment variables must be accurately configured within the Vercel project settings. These variables are critical for connecting to external services such as Supabase, Stripe, and Resend. The following table lists the essential environment variables that need to be set for the **Production**, **Preview**, and **Development** environments:

| Environment Variable | Description |
| :------------------- | :---------- |
| `NEXT_PUBLIC_SUPABASE_URL` | The URL of your Supabase project. |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | The anonymous public key for your Supabase project. |
| `ADMIN_PASSWORD` | The secure password for accessing the admin dashboard. |
| `STRIPE_SECRET_KEY` | Your Stripe secret key (use live key for production). |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Your Stripe publishable key (use live key for production). |
| `STRIPE_WEBHOOK_SECRET` | The secret for verifying Stripe webhook signatures. |
| `RESEND_API_KEY` | Your API key for the Resend email service. |
| `ORDER_NOTIFICATION_EMAIL` | The email address to receive new order notifications. |

### Build and Dependency Verification

Prior to deployment, a local build verification is essential. Executing `npm run build` locally should complete without any errors, indicating that the application is ready for compilation. Furthermore, a thorough check of the `package.json` file is required to ensure that all newly introduced dependencies, such as `@supabase/supabase-js`, `stripe`, and `resend`, are correctly listed. This prevents deployment failures due to missing packages.

### External Service Configurations

Proper configuration of external services is paramount for the application's functionality. The production webhook endpoint for Stripe must be accurately configured within the Stripe Dashboard, and its corresponding signing secret needs to be updated in Vercel's environment variables. If a custom domain is utilized for email services via Resend, it is imperative to ensure that this domain has been successfully verified within the Resend dashboard.

## 2. Manual Test Checklist

Upon successful deployment, a series of manual tests should be conducted to comprehensively verify the functionality and feature parity of the integrated Tsuya project. This section outlines the key test scenarios across different functional areas.

### Core E-commerce Functionality

**Product Browsing and Display:** It is crucial to confirm that products are being correctly fetched from the Supabase backend and are displayed accurately on the shop page. This includes verifying product details, images, and pricing. 

**Shopping Cart Operations:** Users should be able to add multiple items to their cart, adjust quantities, and remove items without issues. A critical test involves verifying that the contents of the shopping cart persist across different browsing sessions, leveraging the implemented localStorage persistence. The cart item count displayed in the navigation bar should also accurately reflect the number of items in the cart.

**Favorites Management:** The ability to add products to a favorites list and remove them should be tested. Similar to the cart, favorited items must persist across page reloads. The dedicated favorites page should correctly display all saved items.

**Guest Checkout Process:** The entire guest checkout flow needs to be validated. This includes successfully entering shipping address and contact information. Verification should extend to ensuring that shipping rates are accurately calculated and applied during the checkout process.

**Payment Processing:** Utilizing a Stripe test card, a complete purchase transaction should be simulated. The system should successfully process the payment via Stripe PaymentIntents, and the user should be seamlessly redirected to the thank-you page upon completion. 

**Order Creation Verification:** Following a successful test payment, the Supabase `orders` table must be inspected to confirm that a new order record has been created. This record should contain all the correct order details, including the accurate payment status.

### Admin Dashboard Functionality

**Admin Authentication:** Access to the admin dashboard is secured via a dedicated login page at `/admin/login`. The authentication process, using the configured `ADMIN_PASSWORD`, must be thoroughly tested to ensure only authorized personnel can gain access.

**Product Management:** The full suite of Product CRUD (Create, Read, Update, Delete) operations within the admin dashboard requires validation. This includes successfully creating new products, uploading images to Supabase Storage, updating existing product details, and deleting products. All changes made in the admin panel should be immediately reflected on the public-facing shop page.

**Order Management:** Administrators should be able to view a comprehensive list of all orders, access detailed information for each order, and update order statuses (e.g., from 'pending' to 'shipped').

**Analytics and Reporting:** The analytics charts integrated into the admin dashboard, covering sales, inventory, and category performance, should be reviewed to ensure they are displaying data accurately and meaningfully.

**Shipping Rate Management:** The CRUD operations for managing shipping rates within the admin settings need to be tested. This includes adding new shipping rates, modifying existing ones, and deleting obsolete rates, with verification that these changes are correctly applied during the checkout process.

### Email Notifications

**Customer Order Confirmation:** After a successful purchase, a confirmation email should be automatically sent to the customer's provided email address. The content and formatting of this email should be accurate and professional.

**Admin New Order Notification:** Concurrently, a new order notification email should be dispatched to the `ORDER_NOTIFICATION_EMAIL` configured for the administrator. This ensures timely awareness of new transactions.

## 3. Final Launch Steps

This section outlines the critical final steps to be taken before the integrated Tsuya project is officially launched to the public.

**Codebase Clean-up:** All `TODO` comments within the codebase should be addressed, and any `console.log` statements should be either removed or replaced with a more robust logging mechanism suitable for a production environment.

**Production Key Configuration:** A crucial step involves updating all Stripe and Resend API keys to their respective production versions within the Vercel environment variables. This ensures that live transactions and email communications are handled correctly.

**Domain and SSL Verification:** The custom domain for the project must be correctly configured and pointed to Vercel. Furthermore, it is essential to verify that the site is served securely over HTTPS with an active and valid SSL certificate.

**Performance and Monitoring:** Basic performance testing should be conducted to ensure optimal loading times and responsiveness. Additionally, error monitoring tools (e.g., Sentry, Vercel Analytics) should be configured to proactively identify and address any issues that may arise in production.

**Data Backup Strategy:** A robust backup strategy for the Supabase data must be established and verified. This is a critical measure to prevent data loss and ensure business continuity.

**Stakeholder Review:** A final comprehensive review of all integrated features by relevant stakeholders is recommended to ensure that all requirements and expectations have been met before the official launch.
