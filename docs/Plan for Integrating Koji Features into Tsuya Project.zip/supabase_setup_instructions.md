# SUPABASE SETUP INSTRUCTIONS

This document provides detailed instructions for setting up the Supabase backend for the Tsuya project, including database schema migrations, storage bucket configuration, and Row Level Security (RLS) policies.

## 1. Supabase Project Initialization

1.  **Create a Project:** Log in to your [Supabase Dashboard](https://supabase.com/dashboard) and create a new project.
2.  **Obtain API Credentials:** Once the project is provisioned, navigate to **Settings** → **API** and copy the following values:
    *   **Project URL:** Set this as `NEXT_PUBLIC_SUPABASE_URL` in your `.env.local` and Vercel environment variables.
    *   **anon public key:** Set this as `NEXT_PUBLIC_SUPABASE_ANON_KEY` in your `.env.local` and Vercel environment variables.

## 2. Database Schema Migrations

Execute the following SQL commands in the Supabase **SQL Editor** to create the necessary tables and indexes.

### Create Tables

```sql
-- Products table
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10, 2) NOT NULL,
  cost NUMERIC(10, 2),
  category TEXT NOT NULL,
  image_url TEXT,
  stock INTEGER DEFAULT 0,
  sizes JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Categories table
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  image_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Orders table
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id TEXT UNIQUE NOT NULL,
  email TEXT NOT NULL,
  items JSONB NOT NULL,
  subtotal NUMERIC(10, 2) NOT NULL,
  taxes NUMERIC(10, 2) NOT NULL,
  shipping NUMERIC(10, 2) NOT NULL,
  total NUMERIC(10, 2) NOT NULL,
  status TEXT DEFAULT 'pending',
  shipping_address JSONB NOT NULL,
  payment_intent_id TEXT,
  payment_status TEXT DEFAULT 'pending',
  payment_method TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Shipping Rates table
CREATE TABLE IF NOT EXISTS shipping_rates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  country_code TEXT NOT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(country_code)
);

-- Favorites table
CREATE TABLE favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, product_id)
);
```

### Create Indexes

```sql
-- Indexes for performance
CREATE INDEX idx_products_category ON products(category);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX idx_orders_email ON orders(email);
CREATE INDEX idx_orders_payment_intent_id ON orders(payment_intent_id);
CREATE INDEX idx_orders_payment_status ON orders(payment_status);
CREATE INDEX idx_shipping_rates_country ON shipping_rates(country_code);
CREATE INDEX idx_favorites_user_product ON favorites(user_id, product_id);
```

## 3. Row Level Security (RLS) Policies

Enable RLS on all tables and configure the following policies to ensure secure data access.

### Enable RLS

```sql
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE shipping_rates ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorites ENABLE ROW LEVEL SECURITY;
```

### Configure Policies

```sql
-- Products Policies
CREATE POLICY "Allow public read access to products" ON products FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to products" ON products FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Categories Policies
CREATE POLICY "Allow public read access to categories" ON categories FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to categories" ON categories FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Orders Policies
CREATE POLICY "Allow orders insert for checkout" ON orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow admin full access to orders" ON orders FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Shipping Rates Policies
CREATE POLICY "Allow public read shipping_rates" ON shipping_rates FOR SELECT USING (true);
CREATE POLICY "Allow admin full access to shipping_rates" ON shipping_rates FOR ALL USING (auth.role() = 'authenticated') WITH CHECK (auth.role() = 'authenticated');

-- Favorites Policies
CREATE POLICY "Allow user to view their own favorites" ON favorites FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Allow user to insert their own favorites" ON favorites FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Allow user to delete their own favorites" ON favorites FOR DELETE USING (auth.uid() = user_id);
```

## 4. Supabase Storage Configuration

1.  **Create Bucket:** In the Supabase Dashboard, navigate to **Storage** and create a new bucket named `product-images`.
2.  **Set Public Access:** Ensure the bucket is marked as **Public**.
3.  **Configure Storage Policies:**
    *   **Select Policy:** Allow public read access to all files in the `product-images` bucket.
    *   **Insert/Update/Delete Policy:** Restrict these operations to authenticated users (administrators) only.

## 5. Environment Variables

Ensure the following variables are correctly set in your `.env.local` and Vercel project settings:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-public-key-here
```

Replace `your-project-id` and `your-anon-public-key-here` with the actual values from your Supabase project settings.
