# STRIPE SETUP INSTRUCTIONS

This document provides a step-by-step guide for setting up Stripe payment integration for the Tsuya project.

## 1. Stripe Account Configuration

1.  **Create an Account:** If you don't have one, sign up for a [Stripe account](https://stripe.com).
2.  **Obtain API Keys:** Navigate to the **Developers** → **API keys** section in your Stripe Dashboard.
    *   **Publishable key:** Copy this and set it as `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`.
    *   **Secret key:** Copy this and set it as `STRIPE_SECRET_KEY`.
    *   *Note: Use test keys (`pk_test_...`, `sk_test_...`) for development and live keys for production.*

## 2. Webhook Configuration

Webhooks are essential for receiving real-time notifications from Stripe about payment events.

### Local Development (using Stripe CLI)

1.  **Install Stripe CLI:** Follow the instructions on the [Stripe CLI documentation](https://stripe.com/docs/stripe-cli) to install the CLI for your operating system.
2.  **Login:** Run `stripe login` in your terminal.
3.  **Forward Webhooks:** Run the following command to forward webhooks to your local development server:
    ```bash
    stripe listen --forward-to localhost:3000/api/webhooks/stripe
    ```
4.  **Obtain Webhook Secret:** The command above will output a webhook signing secret (starting with `whsec_`). Copy this and set it as `STRIPE_WEBHOOK_SECRET` in your `.env.local` file.

### Production (Deployed Site)

1.  **Add Endpoint:** In the Stripe Dashboard, navigate to **Developers** → **Webhooks** and click **Add endpoint**.
2.  **Configure URL:** Enter your production webhook URL: `https://yourdomain.com/api/webhooks/stripe`.
3.  **Select Events:** Choose the following events to listen for:
    *   `payment_intent.succeeded`
    *   `payment_intent.payment_failed`
4.  **Obtain Signing Secret:** Once the endpoint is created, click on it to reveal the **Signing secret**. Copy this and set it as `STRIPE_WEBHOOK_SECRET` in your Vercel environment variables.

## 3. Environment Variables

Ensure the following variables are correctly configured in your environment:

```env
STRIPE_SECRET_KEY=sk_test_your_secret_key_here
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key_here
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret_here
```

## 4. Testing the Integration

1.  **Use Test Cards:** When testing in development mode, use Stripe's [test card numbers](https://stripe.com/docs/testing#cards) (e.g., `4242 4242 4242 4242` for a successful payment).
2.  **Verify Webhook Events:** Check the **Developers** → **Webhooks** section in the Stripe Dashboard to monitor incoming events and ensure they are being processed correctly by your server.
3.  **Check Order Status:** After a successful test payment, verify that the order status in your Supabase database has been updated to `processing`.
