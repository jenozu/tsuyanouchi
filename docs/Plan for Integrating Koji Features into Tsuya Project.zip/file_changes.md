# FILE-BY-FILE CHANGE LIST

This document details all the file additions, modifications, and deletions required to integrate Koji's features into the Tsuya project.

## Added Files

| File Path | Description |
| :--- | :--- |
| `/lib/supabase-client.ts` | Initializes the Supabase client for database and storage interaction. |
| `/lib/supabase-helpers.ts` | Contains helper functions for Supabase operations (products, orders, shipping). |
| `/lib/cart-context.tsx` | Implements the shopping cart context with localStorage persistence. |
| `/lib/favorites-context.tsx` | Implements the favorites context with localStorage persistence. |
| `/lib/stripe.ts` | Server-side utilities for Stripe PaymentIntents and webhook verification. |
| `/lib/email.ts` | Utilities for sending order confirmation and notification emails via Resend. |
| `/app/cart/page.tsx` | The shopping cart page UI. |
| `/app/favorites/page.tsx` | The favorites page UI. |
| `/app/checkout/page.tsx` | The checkout page UI, including Stripe Elements integration. |
| `/app/admin/login/page.tsx` | Simple password-based admin login page. |
| `/app/api/admin/auth/route.ts` | API route for admin password verification. |
| `/app/api/payments/create-intent/route.ts` | API route to create a Stripe PaymentIntent. |
| `/app/api/payments/update-intent/route.ts` | API route to update a Stripe PaymentIntent with order metadata. |
| `/app/api/webhooks/stripe/route.ts` | Stripe webhook handler for processing payment events. |
| `/app/api/shipping/rates/route.ts` | API route to fetch shipping rates from Supabase. |

## Modified Files

| File Path | Change Description |
| :--- | :--- |
| `/package.json` | Add dependencies: `@supabase/supabase-js`, `stripe`, `@stripe/stripe-js`, `@stripe/react-stripe-js`, `resend`. Remove legacy dependencies. |
| `/lib/products.ts` | Update to fetch product data from Supabase instead of local JSON storage. |
| `/components/navbar.tsx` | Integrate cart and favorites icons/counts; update admin link. |
| `/app/layout.tsx` | Wrap application with `CartProvider` and `FavoritesProvider`. |
| `/app/admin/page.tsx` | Merge Koji's admin dashboard features (CRUD, orders, analytics) and enforce password auth. |
| `/app/api/products/route.ts` | Update to handle product CRUD via Supabase. |
| `/app/api/products/[id]/route.ts` | Update to handle single product operations via Supabase. |
| `/app/api/upload/route.ts` | Update to handle image uploads to Supabase Storage. |
| `/app/thank-you/page.tsx` | Update to display order summary and "Continue Shopping" button. |
| `/components/navbar-wrapper.tsx` | Update to handle the new admin authentication state. |
| `/auth.ts` | Reconfigure or remove legacy `next-auth` logic in favor of simple admin auth. |
| `/.env.local.example` | Add all new environment variables for Supabase, Stripe, and Resend. |
| `/README.md` | Update with new setup and deployment instructions. |

## Deleted Files

| File Path | Reason for Deletion |
| :--- | :--- |
| `/lib/product-storage.ts` | Replaced by Supabase backend and `lib/supabase-helpers.ts`. |
| `/sanity.config.ts` | Sanity CMS is no longer used. |
| `/sanity/` (directory) | Sanity CMS configuration and schemas are no longer used. |
| `/data/products.json` | Data migrated to Supabase database. |
