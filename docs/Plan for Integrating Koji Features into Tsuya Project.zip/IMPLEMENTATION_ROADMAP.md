# 🚀 TSUYA NO UCHI - Complete E-Commerce Implementation Roadmap

**From Current Setup to Fully Functional Sales Platform**

---

## 📋 Table of Contents

1. [Executive Summary](#executive-summary)
2. [Opportunities from Gemini Version](#opportunities-from-gemini-version)
3. [Phase 1: Enhanced Product Management](#phase-1-enhanced-product-management)
4. [Phase 2: Authentication & User Accounts](#phase-2-authentication--user-accounts)
5. [Phase 3: Shopping Cart & Checkout](#phase-3-shopping-cart--checkout)
6. [Phase 4: Payment Processing (Stripe)](#phase-4-payment-processing-stripe)
7. [Phase 5: Order Management](#phase-5-order-management)
8. [Phase 6: Email Notifications](#phase-6-email-notifications)
9. [Phase 7: Advanced Features](#phase-7-advanced-features)
10. [Deployment & Production Checklist](#deployment--production-checklist)
11. [Security Best Practices](#security-best-practices)
12. [Cost Breakdown](#cost-breakdown)
13. [Implementation Timeline](#implementation-timeline)

---

## Executive Summary

This document provides a complete roadmap to transform your TSUYA NO UCHI website from a content showcase into a **fully functional e-commerce platform** ready to process real sales. The implementation is divided into 7 phases, prioritized by business impact.

### Current Status ✅
- Beautiful Next.js 15 website
- Sanity CMS integration
- Product display pages
- Responsive design

### Missing Components ❌
- User authentication & accounts
- Shopping cart persistence
- Payment processing
- Order management system
- Email notifications
- Admin analytics dashboard
- AI-powered features

### End Goal 🎯
A production-ready e-commerce platform where customers can:
- Browse products
- Create accounts (Google Sign-in)
- Add items to cart
- Complete purchases with Stripe
- Track orders
- Receive email confirmations

---

## Opportunities from Gemini Version

### 1. 🎨 **Custom Admin Dashboard** (HIGH IMPACT)

**What Gemini Has:**
- Beautiful analytics dashboard with charts (Recharts)
- Real-time inventory tracking
- Low stock alerts
- Revenue/cost/profit analytics
- Category distribution pie charts
- Product CRUD interface

**Implementation Value:**
- ✅ Better inventory management
- ✅ Business insights at a glance
- ✅ No need for external analytics tools
- ✅ Saves ~$20-50/month on SaaS subscriptions

**Status:** ✅ Already implemented at `/admin`

---

### 2. 🤖 **AI-Powered Product Descriptions** (MEDIUM IMPACT)

**What Gemini Has:**
- One-click AI description generation
- Uses AI for brand-aware copywriting
- Saves hours of manual writing

**Our Implementation:**
- ✅ One-click AI description generation
- ✅ Uses OpenAI GPT-4o-mini (better quality!)
- ✅ Brand-aware copywriting
- ✅ Faster product uploads
- ✅ Consistent brand voice
- ✅ SEO-optimized descriptions
- ✅ Cost: ~$0.00015 per generation (super cheap!)

**Status:** ✅ Already implemented (needs OPENAI_API_KEY)

---

### 3. 💾 **Simple File-Based Storage** (COMPLETED)

**What Gemini Has:**
- localStorage for quick demos
- No database complexity

**Our Improvement:**
- ✅ VPS file storage (`/data/products.json`)
- ✅ Image uploads to `/public/uploads/`
- ✅ No Sanity CMS complexity
- ✅ Full control over data

**Status:** ✅ Implemented

---

### 4. ⭐ **Favorites/Wishlist System** (HIGH IMPACT)

**What Gemini Has:**
- Heart icon on products
- Persistent favorites list
- Favorites page view

**Implementation Value:**
- ✅ Increases conversions (25-30% higher)
- ✅ Encourages return visits
- ✅ Marketing opportunity (abandoned wishlist emails)

**Status:** ❌ Not yet implemented

**Implementation Guide:** [See Phase 3](#favorites-wishlist-implementation)

---

### 5. 📊 **Business Analytics** (MEDIUM IMPACT)

**What Gemini Has:**
- COGS (Cost of Goods Sold) tracking
- Profit margin calculations
- Revenue trends
- Mock sales data visualization

**Implementation Value:**
- ✅ Track actual profitability
- ✅ Make data-driven decisions
- ✅ Identify best-selling products

**Status:** ✅ UI implemented (needs real order data)

---

### 6. 📤 **CSV Bulk Upload** (MEDIUM IMPACT)

**What Gemini Has:**
- Upload multiple products via CSV
- Faster than adding one-by-one

**Implementation Value:**
- ✅ Speed up product catalog building
- ✅ Easy inventory updates
- ✅ Import from spreadsheets

**Status:** ❌ Not yet implemented

**Implementation Guide:** [See Phase 1](#csv-bulk-upload)

---

## Phase 1: Enhanced Product Management

**Goal:** Complete the product management system with missing features

### 1.1 CSV Bulk Upload

**Dependencies:** None
**Time Estimate:** 2-3 hours

**Implementation:**

```typescript
// app/api/products/bulk/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { bulkAddProducts } from '@/lib/product-storage'
import Papa from 'papaparse'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File
    
    if (!file) {
      return NextResponse.json({ error: 'No file uploaded' }, { status: 400 })
    }
    
    const text = await file.text()
    const result = Papa.parse(text, { header: true })
    
    // Validate and transform CSV data
    const products = result.data.map((row: any) => ({
      name: row.name,
      description: row.description || '',
      price: parseFloat(row.price),
      cost: row.cost ? parseFloat(row.cost) : undefined,
      category: row.category,
      imageUrl: row.imageUrl || '',
      stock: parseInt(row.stock) || 0,
      sizes: row.sizes ? JSON.parse(row.sizes) : [],
    }))
    
    const added = await bulkAddProducts(products)
    
    return NextResponse.json({ 
      success: true, 
      count: added.length,
      products: added 
    })
  } catch (error) {
    console.error('Bulk upload error:', error)
    return NextResponse.json({ error: 'Failed to process CSV' }, { status: 500 })
  }
}
```

**Install dependency:**
```bash
npm install papaparse
npm install --save-dev @types/papaparse
```

**CSV Format Example:**
```csv
name,description,price,cost,category,imageUrl,stock,sizes
"Moonlight Print","Beautiful night scene",45,15,"Art Prints","/images/moon.jpg",20,"[{""label"":""A4"",""price"":45},{""label"":""A3"",""price"":65}]"
```

**Add to Admin UI:**
```typescript
// In app/admin/page.tsx
const handleCSVUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
  const file = e.target.files?.[0]
  if (!file) return

  const formData = new FormData()
  formData.append('file', file)

  const res = await fetch('/api/products/bulk', {
    method: 'POST',
    body: formData,
  })

  const data = await res.json()
  alert(`Successfully uploaded ${data.count} products!`)
  refreshProducts()
}
```

---

### 1.2 Product Image Gallery

**Current:** Single image per product
**Improvement:** Multiple images with thumbnails

**Implementation:**

```typescript
// Update Product interface in lib/product-storage.ts
export interface Product {
  // ... existing fields
  images?: string[] // Array of image URLs
  imageUrl: string // Primary image (backwards compatible)
}
```

**Update upload to handle multiple files:**

```typescript
// app/api/upload-multiple/route.ts
export async function POST(request: NextRequest) {
  const formData = await request.formData()
  const files = formData.getAll('files') as File[]
  
  const uploadedUrls = []
  
  for (const file of files) {
    // ... same upload logic
    uploadedUrls.push(`/uploads/${filename}`)
  }
  
  return NextResponse.json({ urls: uploadedUrls })
}
```

---

### 1.3 Product Categories Management

**Implementation:**

```typescript
// lib/categories.ts
import fs from 'fs'
import path from 'path'

const CATEGORIES_FILE = path.join(process.cwd(), 'data', 'categories.json')

export interface Category {
  id: string
  name: string
  slug: string
  description?: string
  imageUrl?: string
}

export function getCategories(): Category[] {
  if (!fs.existsSync(CATEGORIES_FILE)) {
    const defaults = [
      { id: 'prints', name: 'Art Prints', slug: 'prints' },
      { id: 'originals', name: 'Original Artwork', slug: 'originals' },
      { id: 'accessories', name: 'Accessories', slug: 'accessories' },
    ]
    fs.writeFileSync(CATEGORIES_FILE, JSON.stringify(defaults, null, 2))
    return defaults
  }
  
  return JSON.parse(fs.readFileSync(CATEGORIES_FILE, 'utf-8'))
}

// Similar functions: addCategory, updateCategory, deleteCategory
```

---

## Phase 2: Authentication & User Accounts

**Goal:** Enable user registration, login, and account management

### 2.1 NextAuth.js Setup with Google Sign-In

**Why NextAuth.js?**
- ✅ Most popular auth solution for Next.js
- ✅ Built-in Google OAuth support
- ✅ Session management included
- ✅ Works with Next.js 15 App Router

**Time Estimate:** 3-4 hours

**Step 1: Install Dependencies**

```bash
npm install next-auth@beta
```

**Step 2: Configure Google OAuth**

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create new project or select existing
3. Enable "Google+ API"
4. Go to "Credentials" → "Create Credentials" → "OAuth 2.0 Client ID"
5. Set authorized redirect URI: `http://localhost:3000/api/auth/callback/google`
6. For production: `https://yourdomain.com/api/auth/callback/google`
7. Copy Client ID and Client Secret

**Step 3: Environment Variables**

```bash
# .env.local
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-here-generate-with-openssl-rand-base64-32

GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret
```

**Step 4: Create Auth Configuration**

```typescript
// lib/auth.ts
import NextAuth from "next-auth"
import GoogleProvider from "next-auth/providers/google"

export const { handlers, signIn, signOut, auth } = NextAuth({
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
  ],
  callbacks: {
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.sub!
      }
      return session
    },
  },
  pages: {
    signIn: '/auth/signin',
  },
})
```

**Step 5: Create API Route Handler**

```typescript
// app/api/auth/[...nextauth]/route.ts
import { handlers } from "@/lib/auth"

export const { GET, POST } = handlers
```

**Step 6: Create Sign-In Page**

```typescript
// app/auth/signin/page.tsx
import { signIn } from "@/lib/auth"
import { Button } from "@/components/ui/button"

export default function SignInPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#F9F8F4]">
      <div className="bg-white p-8 shadow-lg max-w-md w-full">
        <h1 className="text-2xl font-serif text-center mb-6">Sign In to TSUYA NO UCHI</h1>
        
        <form
          action={async () => {
            "use server"
            await signIn("google", { redirectTo: "/" })
          }}
        >
          <Button type="submit" className="w-full">
            <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
              {/* Google icon SVG */}
            </svg>
            Continue with Google
          </Button>
        </form>
      </div>
    </div>
  )
}
```

**Step 7: Add Auth to Navbar**

```typescript
// components/navbar.tsx
import { auth } from "@/lib/auth"
import { SignOutButton } from "@/components/auth/signout-button"

export default async function Navbar() {
  const session = await auth()
  
  return (
    <nav>
      {/* ... existing nav */}
      {session?.user ? (
        <div className="flex items-center gap-3">
          <img 
            src={session.user.image || ''} 
            alt={session.user.name || ''} 
            className="w-8 h-8 rounded-full"
          />
          <span>{session.user.name}</span>
          <SignOutButton />
        </div>
      ) : (
        <Button asChild>
          <Link href="/auth/signin">Sign In</Link>
        </Button>
      )}
    </nav>
  )
}
```

**Step 8: Create Sign-Out Button (Client Component)**

```typescript
// components/auth/signout-button.tsx
'use client'

import { signOut } from "next-auth/react"
import { Button } from "@/components/ui/button"

export function SignOutButton() {
  return (
    <Button onClick={() => signOut()} variant="ghost">
      Sign Out
    </Button>
  )
}
```

---

### 2.2 User Profile & Account Page

**Implementation:**

```typescript
// app/account/page.tsx
import { auth } from "@/lib/auth"
import { redirect } from "next/navigation"